import { combineReducers } from 'redux';
import auth from './auth';

const rootReducers = combineReducers({
  auth,
});

export default rootReducers;
